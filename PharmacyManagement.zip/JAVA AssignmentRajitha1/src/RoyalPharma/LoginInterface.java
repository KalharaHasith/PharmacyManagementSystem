/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package RoyalPharma;

/**
 *
 * @author user
 */
public interface LoginInterface {
    public Integer getUId();
    public void setUId(Integer uname);
    public String getPass();
    public void setPass(String pass);
    public String getULevel();
    public void setULevel(String userLevel);
}
